/**
 * @license Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */

CKEDITOR.plugins.setLang( 'placeholder', 'el', {
	title: 'Ιδιότητες Υποκαθιστόμενου Κειμένου',
	toolbar: 'Δημιουργία Υποκαθιστόμενου Κειμένου',
	name: 'Όνομα Υποκαθιστόμενου Κειμένου',
	invalidName: 'Το υποκαθιστόμενου κειμένο πρέπει να μην είναι κενό και να μην έχει κανέναν από τους ακόλουθους χαρακτήρες: [, ], <, >',
	pathName: 'υποκαθιστόμενο κείμενο'
} );
